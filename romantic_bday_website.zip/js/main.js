// Simple interactivity: play music, confetti, download page
document.addEventListener('DOMContentLoaded', function(){
  const bgm = document.getElementById('bgm');
  const playBtn = document.getElementById('playBtn');
  const confettiBtn = document.getElementById('confettiBtn');
  const downloadBtn = document.getElementById('downloadBtn');

  playBtn.addEventListener('click', async ()=>{
    try {
      await bgm.play();
      playBtn.textContent = 'Pause Music';
      playBtn.onclick = ()=>{ bgm.pause(); playBtn.textContent='Play Music'; playBtn.onclick=null; };
    } catch(e){
      alert('Autoplay blocked — click play on the browser or allow sound.');
    }
  });

  confettiBtn.addEventListener('click', ()=>{
    // simple confetti using emojis appended briefly
    const overlay = document.getElementById('overlay');
    for(let i=0;i<30;i++){
      const el = document.createElement('div');
      el.textContent = '🎉';
      el.style.position='fixed';
      el.style.left = (Math.random()*100)+'%';
      el.style.top = (Math.random()*20)+'%';
      el.style.fontSize = (12+Math.random()*36)+'px';
      el.style.opacity = Math.random();
      el.style.transform = 'translateY(0)';
      el.style.transition = 'transform 2s linear, opacity 2s';
      overlay.appendChild(el);
      setTimeout(()=> el.style.transform = 'translateY(90vh) rotate('+Math.random()*720+'deg)',10);
      setTimeout(()=> el.style.opacity=0,1600);
      setTimeout(()=> el.remove(),2200);
    }
  });

  downloadBtn.addEventListener('click', ()=>{
    // create downloadable zip of the page (simple approach: prompt user to save HTML)
    const blob = new Blob([document.documentElement.outerHTML], {type:'text/html'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'Happy_Birthday_Jass.html';
    a.click();
  });
});
